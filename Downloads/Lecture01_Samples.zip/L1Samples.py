#!/usr/bin/env python3.7

"""
Script samples for ECE 364.
"""

import os
import math

def printVariableWithType(var):
    """
    Printing.
    """
    # Another way for printing: print("Variable is of type", type(var), " and its value is: ", var)
    print("Variable is of type {} and its value is: {} ".format(type(var), var))


def printSomePrimitiveTypes():
    """
    Examples of integral types.
    """
    s = 'This is a string. "WSS" '
    printVariableWithType(s)

    x = "This is a " + ' concatenated ' + "string"
    printVariableWithType(x)

    x = 1
    printVariableWithType(x)

    y = int(2**80)
    printVariableWithType(y)

    w = math.pi
    printVariableWithType(w)

    z = True
    printVariableWithType(z)

    s = "This is some string to display"
    printVariableWithType(s)


def workWithStrings():
    c = "Combining a string " + 'with' + """ another string."""
    printVariableWithType(c)

    x = 1.0
    y = 2.0

    print("Is the value of {0} > {1}? The Answer is {2}".format(x, y, x > y))

    z = x < y
    print(f"Is the value of {x} < {y}? The Answer is {z}")



def workWithLists():
    """
    Line one.
    line two.
    """

    vec = [0, 1, 4, 9, 16, 25, 36, 49, 64, 81, 100]
    vec2 = vec

    print("Length of the List is: ".format(len(vec)))
    print(vec[1])
    print(vec[0:])
    print(vec[:5])
    print(vec[1:6]) # first .... (Last-1)
    i = 1
    print(vec[i:i+5])
    print()
    print("List: {}".format(vec))
    rlist = vec.reverse()   # INCORRECT! But no errors.

    print("Reversed: {}".format(vec))
    print("Reversed2: {}".format(rlist))
    print("List2: {}".format(vec2))

    vec.reverse()
    vec.append(121)

    print()
    print("After appending: ".format(vec))

    print("Negative indices: {}, {}".format(vec[-1], vec[-5]))


def runWorkFlow():

    x = 1

    if x == 1:
        print("Yes, it is correct!")

    inc = 0
    while inc <= 3:
        print(f" Current Value = {inc}")
        inc += 1

    vector = [0, 1, 4, 9, 16, 25, 36, 49, 64, 81, 100]

    # Get the vector norm, which is the square-root of the sum of the elements squared.
    elementSum = 0

    for element in vector:
        elementSum += element ** 2.0

    vectorNorm = math.sqrt(elementSum)
    print(f"The 2nd norm of {vector} = {vectorNorm}")

    vector = ["A", "B", "C", 2, math.pi]
    # Working with indices.
    for index, element in enumerate(vector):
        print(f"The element @ index {index} = {element}")

    # Working with indices.
    for index, element in range(len(vector)):
        element = vector[index]
        print(f"The element @ index {index} = {element}")

def function2():

    if True:
        pass

    pass

if __name__ == "__main__":
    printSomePrimitiveTypes()
