#!/usr/bin/env python3.7

"""
Script samples for ECE 364.
"""

import os
import math

# Function Declaration without types.
def addTwoNumbers(a, b):

    return a + b


# Function Declaration with types.
def addTwoFloats(a: float, b: float) -> float:

    return a + b


def runGoodTest1():

    x = 1.0
    y = 2.0

    z = addTwoNumbers(x, y)

    print(f"{x} + {y} = {z}")


def runGoodTest2():

    x = 1.0
    y = 2.0

    z = addTwoFloats(x, y)

    print(f"{x} + {y} = {z}")


def runBadTest1():

    x = "Hello"
    y = 2.0

    z = addTwoNumbers(x, y)
    print(f"{x} + {y} = {z}")


def runBadTest2():

    x = "Hello"
    y = 2.0

    z = addTwoFloats(x, y)

    print(f"{x} + {y} = {z}")