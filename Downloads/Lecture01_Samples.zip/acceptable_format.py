#!/usr/local/bin/python3.7      #<- Shebang statement for executable file.

#######################################################
#   Author:     <Your Full Name>
#   email:      <Your Email>
#   ID:         <Your course ID, e.g. ee364j20>
#   Date:       <Start Date>
#######################################################

import os          
import sys          # List of module import statements
import math         # Each one on a line


# Module level Variables. (Write this statement verbatim.)
#######################################################
DataPath = os.path.expanduser('<Path Provided to You>')


# USE FOUR SPACES AS YOUR INDENTATION. DO NOT USE A TAB.
def func3(a: float, b: float) -> float:
    """
    Function level comments. Refer to Google Python Style Guide.
    """

    c = a + b + 10
    return c

def func2(x: int, w: int, z: int) -> int:
    """
    Function level comments. Refer to Google Python Style Guide.
    """
    y = x + w - z

    return y


if __name__ == "__main__":

    # Write anything here to test your code.
    v1 = func3(4, 3)
    v2 = func2(10, 11, 3)

    result = 'func1(4, 3) = "{0}", func2(10, 11, 3) = "{1}"'.format(v1, v2)
    print(result)
