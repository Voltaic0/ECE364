#!/usr/local/bin/python3.7

"""
Script samples for ECE 364: THIS IS NOT A GOOD SCRIPT FORMAT.
"""

print("----- Beginning a program run -----")

print()

x1 = 3
x2 = 10

total = x1 + x2

print("The sum of {0} and {1} is {2}".format(x1, x2, total))

print()

print("----- The End -----")
